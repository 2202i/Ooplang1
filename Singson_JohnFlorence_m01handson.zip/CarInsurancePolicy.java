
public class CarInsurancePolicy{
    public static void main (String[] args){
        double policyNumber = 10;
        double policyPayment = 10;
        double residentCity = 2009;
        policyData(policyNumber,policyPayment,residentCity);
    }
     public static void policyData(double policyNumber,double policyPayment, double residentCity)
    {
        System.out.println("Policy number : " + policyNumber);
        System.out.println("Policy payment : " + policyPayment);
        System.out.println("City of Residence : " + residentCity);
    }
     public static void policyData(double policyNumber,double policyPayment)
    {
        System.out.println("Policy number : " + policyNumber);
        System.out.println("Policy payment : " + policyPayment);
    }  
     public static void policyData(int residentCity)
    {
        System.out.println("City of Residence : " + residentCity);
    }  
}