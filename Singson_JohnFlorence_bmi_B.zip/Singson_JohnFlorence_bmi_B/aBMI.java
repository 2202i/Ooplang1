import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class aBMI extends javax.swing.JFrame {
//
aBMI() {
    JFrame f = new JFrame();
    
    JLabel label1 = new JLabel("Height:");
    label1.setBounds(100, 100, 100, 100);
    f.add(label1); 
    
    // JLabel label3 = new JLabel("Height(inches):");
    // label3.setBounds(50, 50, 50, 50);
    // f.add(label3); 
    
    JLabel label2 = new JLabel("Weight:");
    label2.setBounds(100, 200, 100, 100);
    f.add(label2); 
    
    JLabel label3 = new JLabel("feet");
    label3.setBounds(265, 100, 700, 100);
    f.add(label3); 
    
    JLabel label4 = new JLabel("pounds");
    label4.setBounds(265, 200, 700, 100);
    f.add(label4); 
    
    JLabel labelResult = new JLabel("BMI :");
    labelResult.setBounds(100, 300, 400, 100);
    f.add(labelResult); 
    
    JTextField textHeight = new JTextField("");
    textHeight.setBounds(150, 120, 100, 50);
    f.add(textHeight); 
    
    JTextField textWeight = new JTextField("");
    textWeight.setBounds(150, 220, 100, 50);
    f.add(textWeight); 
    
    // JTextField textBMI = new JTextField("BMI");
    // textBMI.setBounds(90, 90, 90, 90);
    // f.add(textBMI);
    
     // JTextField textBMI = new JTextField("BMI");
    // textBMI.setBounds(90, 90, 90, 90);
    // f.add(textBMI);
    
    JButton btn = new JButton("Compute BMI");
    btn.setBounds(80, 400, 200, 50);
    
    JButton btn1 = new JButton("Clear");
    btn1.setBounds(280, 400, 200, 50);
    
    JButton btn2 = new JButton("Exit");
    btn2.setBounds(480, 400, 200, 50);
    

btn.addActionListener(new ActionListener(){
    @Override
    public void actionPerformed(ActionEvent e) {
    
    double height = Double.parseDouble(textHeight.getText());    
    double weight = Double.parseDouble(textWeight.getText());
    
    
    
    double bmi = (weight / (height * height)) *703;
    
        
    
    if (bmi < 18.5) {
    labelResult.setText("BMI : "+ bmi);
    } else if (bmi < 25) {
    labelResult.setText("BMI : "+ bmi);
    } else if (bmi < 30) {
    labelResult.setText("BMI : "+ bmi);
    } else {
    labelResult.setText("BMI : "+ bmi);
    }
    }
});

btn1.addActionListener(new ActionListener(){
    @Override
    public void actionPerformed(ActionEvent e) {
    System.out.println("Clearing");
    
    
}    
});  
btn2.addActionListener(new ActionListener(){
    @Override
    public void actionPerformed(ActionEvent e) {
    System.out.println("Exiting");
    System.exit(1);
}    
});   
f.add(btn);
f.add(btn1);
f.add(btn2);

f.setSize(800, 600);
f.setLayout(null);
f.setVisible(true);

}

public static void main(String[] args) {
new aBMI();
}
}